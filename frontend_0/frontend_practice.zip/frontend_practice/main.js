#!/usr/bin/node
alert("hello world");

